TF2 Optimize Mod will help you optimize the game and improve FPS. 
Also used other mods.